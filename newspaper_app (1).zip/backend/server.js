const express = require('express');
const multer = require('multer');
const cors = require('cors');
const path = require('path');
const fs = require('fs');

const app = express();
const PORT = 4000;

app.use(cors());
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'uploads/')
  },
  filename: function (req, file, cb) {
    cb(null, 'daily.pdf')
  }
});
const upload = multer({ storage });

app.post('/upload', upload.single('pdf'), (req, res) => {
  res.json({ message: 'PDF uploaded successfully' });
});

app.get('/latest', (req, res) => {
  const filePath = path.join(__dirname, 'uploads/daily.pdf');
  if (fs.existsSync(filePath)) {
    res.sendFile(filePath);
  } else {
    res.status(404).send('No newspaper uploaded yet.');
  }
});

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
