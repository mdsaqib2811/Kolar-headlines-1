import React, { useState, useEffect } from 'react';
import axios from 'axios';

function App() {
  const [pdfUrl, setPdfUrl] = useState(null);
  const [file, setFile] = useState(null);
  const [message, setMessage] = useState('');

  const fetchPDF = () => {
    setPdfUrl(`http://localhost:4000/latest?${Date.now()}`);
  };

  useEffect(() => {
    fetchPDF();
  }, []);

  const handleUpload = async () => {
    if (!file) return;

    const formData = new FormData();
    formData.append('pdf', file);

    try {
      await axios.post('http://localhost:4000/upload', formData);
      setMessage('Uploaded successfully!');
      fetchPDF();
    } catch (err) {
      setMessage('Upload failed.');
    }
  };

  return (
    <div className="min-h-screen bg-gray-100 p-6">
      <div className="max-w-3xl mx-auto bg-white p-4 rounded shadow">
        <h1 className="text-2xl font-bold mb-4">Daily Newspaper</h1>

        <input type="file" accept="application/pdf" onChange={(e) => setFile(e.target.files[0])} />
        <button
          onClick={handleUpload}
          className="ml-2 px-4 py-2 bg-blue-600 text-white rounded"
        >
          Upload
        </button>
        {message && <p className="mt-2">{message}</p>}

        <div className="mt-6">
          {pdfUrl ? (
            <iframe
              src={pdfUrl}
              width="100%"
              height="600px"
              title="Newspaper PDF"
              className="border"
            />
          ) : (
            <p>No newspaper uploaded yet.</p>
          )}
        </div>
      </div>
    </div>
  );
}

export default App;
